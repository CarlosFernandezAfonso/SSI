/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.myintegrit;

import java.io.FileWriter;
import java.io.IOException;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

/**
 *
 * @author root
 */
public class MainClass {
    
    static Logger log = Logger.getLogger(MainClass.class.getName());
    
    public static void main(String[] args) throws IOException{
       
        
        // === CLOSING CHANNELS ===
        System.out.close();
        System.in.close();
        System.err.close();
        
        
        // === PID DEFINE ===
        String pidRaw = java.lang.management.ManagementFactory.getRuntimeMXBean().getName();
        String pid = pidRaw.split("@", -1)[0];
            System.out.println(pid);

        FileWriter path = new FileWriter("/var/run/myintegrit/myintegrit.pid", false);
        path.write(pid+"\n");
        path.close();
        
        
        
//        log.debug("EXAMPLE : Here is some DEBUG");
//        log.info("EXAMPLE : Here is some INFO");
//        log.warn("EXAMPLE : Here is some WARN");
//        log.error("EXAMPLE : Here is some ERROR");
//        log.fatal("EXAMPLE :  Here is some FATAL");
//        
       

        ForkedService fdb = new ForkedService();
        
       
        
        
        fdb.setDaemon(false);
        fdb.start();
        
        
        // TESTING
        
        //primObject.getAttribsFile("hello.txt");
        
        //primObject.getAllFiles("target");
         //while(true);
    }
}
