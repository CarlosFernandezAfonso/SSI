/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.myintegrit;

import com.mycompany.fileWatcher.FileWatcher;
import java.io.IOException;
import static java.lang.String.format;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.attribute.PosixFileAttributeView;
import java.nio.file.attribute.PosixFileAttributes;
import java.nio.file.attribute.PosixFilePermissions;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author root
 */
public class State {

    static org.apache.log4j.Logger log = org.apache.log4j.Logger.getLogger(State.class.getName());
    
    private HashMap<Path,OwnerData> ficheiros;

    
    public State() {
        this.ficheiros = new HashMap<Path, OwnerData> ();
    }

    public void register(Path dir) {
        try {
            
            PosixFileAttributes attrs = Files.getFileAttributeView(dir, PosixFileAttributeView.class)
                    .readAttributes();
            
            if(this.ficheiros.containsKey(dir)){
                
            }else{
                String filename = dir.getFileName().toString();
                String owner = attrs.owner().getName();
                String permissions = PosixFilePermissions.toString(attrs.permissions());
                this.ficheiros.put(dir,new OwnerData(filename,owner , permissions));
            }
            
            
        } catch (IOException ex) {
            Logger.getLogger(State.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void check(Path dir) {
        boolean res = true;
        
        OwnerData od = ficheiros.get(dir);
        
        if(od == null){
            return;
        }
        
        PosixFileAttributes attrs;
        try {
            attrs = Files.getFileAttributeView(dir, PosixFileAttributeView.class)
                    .readAttributes();
        
        
            if(od.file != dir.getFileName().toString() || 
               od.owner != attrs.owner().getName()     ||
               od.permissions != PosixFilePermissions.toString(attrs.permissions())){
                log.warn(String.format("<%s> Has been Hacked!!! :)", dir));
            }
        } catch (IOException ex) {
            Logger.getLogger(State.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
    }
    
    
    
    
    
}
