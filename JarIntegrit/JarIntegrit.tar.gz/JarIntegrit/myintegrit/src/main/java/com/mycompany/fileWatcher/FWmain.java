/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.fileWatcher;


import com.mycompany.myintegrit.MainClass;
import java.io.FileWriter;
import java.io.IOException;
import org.apache.log4j.Logger;
import sun.misc.Signal;
import sun.misc.SignalHandler;

/**
 *
 * @author root
 */
public class FWmain {
    
    static Logger log = Logger.getLogger(FWmain.class.getName());
    
    
    private FileWatcher FW ;
    
    public static void main(String[] args) throws IOException{
       
        
        // === CLOSING CHANNELS ===
//        System.out.close();
//        System.in.close();
//        System.err.close();
        
         String currentDir = System.getProperty("user.dir");
        System.out.println("Current dir using System:" +currentDir);
        // === PID DEFINE ===
        String pidRaw = java.lang.management.ManagementFactory.getRuntimeMXBean().getName();
        String pid = pidRaw.split("@", -1)[0];
            System.out.println(pid);

        FileWriter path = new FileWriter("/var/run/myintegrit/myintegrit.pid", true);
        path.write(pid+"\n");
        path.close();
        
       
        

        final FileWatcher FW = new FileWatcher();
        FW.init();
        FW.processEvents();
        
        Signal.handle(new Signal("HUP"), new SignalHandler() {
            public void handle(Signal signal)
            {
                try {
                    log.info("Restarting FWatcher");
                    FW.interrupt();
                    FW.init();
                    FW.processEvents();
                } catch (IOException ex) {
                    log.error("IOException");
                }
                
            }
        });
        
        

        
       
    }
}
