/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.myintegrit;

import static com.mycompany.myintegrit.MainClass.log;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import static java.lang.String.format;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.attribute.PosixFileAttributeView;
import java.nio.file.attribute.PosixFileAttributes;
import java.nio.file.attribute.PosixFilePermissions;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author root
 */
public class MyIntegrit {
    ArrayList<String> ficheiros;
    HashMap<File, String> data;
    
    static org.apache.log4j.Logger log = org.apache.log4j.Logger.getLogger(MainClass.class.getName());

    MyIntegrit(ArrayList<String> config) {
        ficheiros = config;
        try {
            init();
        } catch (IOException ex) {
            Logger.getLogger(MyIntegrit.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void resetConfig() throws IOException{
        ArrayList<String> al = new ArrayList<String>();
        
        String line;
        
        BufferedReader br = new BufferedReader(new FileReader("configuration_myintegrit.txt"));
        try {
            line = br.readLine();
            while(line != null){
                al.add(line);
                line = br.readLine();
            }
            
        } finally {
            br.close();
        }
        
        
        
        
        ficheiros = al;
        init();
    }
    
    public boolean compareIter() throws IOException {
        HashMap<File, String> newIter = iter();
        boolean res = true;
        for(File f : data.keySet()){
            if(newIter.containsKey(f) && newIter.get(f).equals(data.get(f))){
                //NADA
            }
            else{
                res = false;
                log.warn("Here is some WARN --- Sistem as been compromised");
                Logger.getLogger(MyIntegrit.class.getName()).log(Level.SEVERE, "Foi encontrada uma diferença no ficheiro" + f.getAbsolutePath());
            }
        }
        return res;
    }
    
    public void init() throws IOException{
        data = iter();
    }
    
    public HashMap<File, String> iter() throws IOException{
        HashMap<File, String> res = new HashMap<File, String>();
        for(String s : ficheiros){
            ArrayList<File> fs = getAllFiles(s);
            for(File f : fs){
                res.put(f, getAttribsFile(f.getAbsolutePath()));
            }
        }
        return res;
    }
        
    
    public ArrayList<File> getAllFiles(String root){
        File file = new  File(root);
        File[] fs = file.listFiles();
        ArrayList<File> res = new ArrayList<File>();
        
        
        for(File f : fs){
            if(f.isDirectory()){
                res.addAll(getAllFiles(f.getAbsolutePath()));
            }
        }
        
        for(int i = 0; i < fs.length; i++){
            res.add(fs[i]);
        }
        
        return res;
    }
    
    public String getAttribsFile(String filepath) throws IOException{
        Path file =  Paths.get(filepath);
        PosixFileAttributes attrs = Files.getFileAttributeView(file, PosixFileAttributeView.class)
           .readAttributes();
//        System.out.format("%s %s %s%n", "hello",
//           attrs.owner().getName(),
//           PosixFilePermissions.toString(attrs.permissions()));
        return format("%s %s%n", 
           attrs.owner().getName(),
           PosixFilePermissions.toString(attrs.permissions()));
    }
}
