package com.mycompany.fileWatcher;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */



import com.mycompany.myintegrit.MainClass;
import com.mycompany.myintegrit.State;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.*;
import static java.nio.file.LinkOption.NOFOLLOW_LINKS;
import static java.nio.file.StandardWatchEventKinds.*;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author root
 */
public class FileWatcher {
   
    static org.apache.log4j.Logger log = org.apache.log4j.Logger.getLogger(FileWatcher.class.getName());
    
    private final WatchService watcher;
    private final boolean recursive;
    private final HashMap<WatchKey, Path> keys;
    private final boolean trace;
    
    private State fileSystem_state ;
    
    
    // Para chamar class :
    //  new FileWatcher(dir, recursive).processEvents();
    
    
    

    FileWatcher() throws IOException {
        this.watcher = FileSystems.getDefault().newWatchService();
        this.keys = new HashMap<WatchKey,Path>();
        this.recursive = false;
        this.fileSystem_state = new State();
        
        // enable trace after initial registration
        this.trace = true;
    }

    private void registerAll(final Path start) throws IOException {
        // register directory and sub-directories
        Files.walkFileTree(start, new SimpleFileVisitor<Path>() {
            @Override
            public FileVisitResult preVisitDirectory(Path dir, BasicFileAttributes attrs)
                throws IOException
            {
                register(dir);
                return FileVisitResult.CONTINUE;
            }
        });
    }

    
    
    private void register(Path dir) throws IOException {
        WatchKey key = dir.register(watcher, ENTRY_CREATE, ENTRY_DELETE, ENTRY_MODIFY);
        if (trace) {
            Path prev = keys.get(key);
            if (prev == null) {

                log.info(String.format("register: %s\n", dir));
                //System.out.format("register: %s\n", dir);
            } else {
                if (!dir.equals(prev)) {
                    log.info(String.format("update: %s -> %s\n", prev, dir));
                    //System.out.format("update: %s -> %s\n", prev, dir);
                }
            }
        }
        keys.put(key, dir);
        this.fileSystem_state.register(dir);
    }
    
    @SuppressWarnings("unchecked")
    static <T> WatchEvent<T> cast(WatchEvent<?> event) {
        return (WatchEvent<T>)event;
    }
    
    
    void interrupt(){
        this.keys.clear();
    }
    
    void processEvents() {
        while(true){

            // wait for key to be signalled
            WatchKey key;
            try {
                key = watcher.take();
            } catch (InterruptedException x) {
                return;
            }

            Path dir = keys.get(key);
            if (dir == null) {
                log.error("WatchKey not recognized!! :: " + dir);
                continue;
            }

            for (WatchEvent<?> event: key.pollEvents()) {
                WatchEvent.Kind kind = event.kind();

                // OVERFLOW event 
                if (kind == OVERFLOW) {
                    continue;
                }

                // Context for directory entry event is the file name of entry
                WatchEvent<Path> ev = cast(event);
                Path name = ev.context();
                Path child = dir.resolve(name);

                // print out event
                log.info(String.format("%s: %s\n", event.kind().name(), child));

                // if a directory is created then we register his children
                if (recursive && (kind == ENTRY_CREATE)) {
                    try {
                        if (Files.isDirectory(child, NOFOLLOW_LINKS)) {
                                registerAll(child);
                        }
                    } catch (IOException ex) {
                        Logger.getLogger(FileWatcher.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
                

            
                //VerifyIntegrity;
                //this.fileSystem_state.check(dir);
                
            }
            

            // reset key and remove from set if directory no longer accessible
            boolean valid = key.reset();
            if (!valid) {
                keys.remove(key);

                // all directories are inaccessible
                if (keys.isEmpty()) {
                    break;
                }
            }
        }
    }

    public void init() throws IOException {
        
        String line;
        
        BufferedReader br = new BufferedReader(new FileReader("/home/tlsl/Desktop/JarIntegrit/myintegrit/configuration_myintegrit.txt"));
        try {
            line = br.readLine();
            
        } finally {
            br.close();
        }
        
        Path dir = Paths.get(line);
       
        // "/home/tlsl/Desktop/JarIntegrit/myintegrit/src"
        if (recursive) {
            log.info("Scanning %s ...\n" + dir);
            registerAll(dir);
            log.info("Done.");
        } else {
            register(dir);
        }

    }
    
    
        

}
