interactive=


filename="/var/run/myintegrit/myintegrit.pid"
pid=$(head -1 $filename)





while [ "$1" != "" ]; do
	kill -$1 
    case $1 in
	SIGHUP    | 1             ) echo "SIGHUP  Sent -- $pid $pid" 
				    sudo kill -$1 $pid 
				    ;;
	SIGINT    | 2             ) echo "SIGHUP  Sent -- $pid $pid" 
								sudo kill -$1 $pid ;;
	SIGQUIT   | 3             ) echo "SIGQUIT Sent -- $pid $pid" 
								sudo kill -$1 $pid ;; 
	SIGILL    | 4             ) echo "SIGILL  Sent -- $pid $pid" 
								sudo kill -$1 $pid ;;
	SIGABRT   | 6             ) echo "SIGABRT Sent -- $pid $pid" 
								sudo kill -$1 $pid ;;
	SIGKILL   | 9             ) echo "SIGKILL Sent -- $pid $pid" 
								sudo kill -$1 $pid ;;
	SIGALRM   | 14            ) echo "SIGALRM Sent -- $pid $pid" 
								sudo kill -$1 $pid ;;
	SIGTERM   | 15            ) echo "SIGTERM Sent -- $pid $pid" 
								sudo kill -$1 $pid ;;
	SIGCHLD   | 20 | 17 | 18  ) echo "SIGCHLD Sent -- $pid $pid" 
								sudo kill -$1 $pid ;;
	SIGCONT   | 19 | 18 | 25  ) echo "SIGCONT Sent -- $pid $pid" 
								sudo kill -$1 $pid ;;
	SIGSTOP   | 17 | 19 | 23  ) echo "SIGSTOP Sent -- $pid $pid" 
								sudo kill -$1 $pid ;;
	SIGTSTP   | 18 | 20 | 24  ) echo "SIGTSTP Sent -- $pid $pid" 
								sudo kill -$1 $pid ;;
	SIGTTIN   | 21 | 21 | 26  ) echo "SIGTTIN Sent -- $pid $pid" 
								sudo kill -$1 $pid ;;
	SIGTTOU   | 22 | 22 | 27  ) echo "SIGTTOU Sent -- $pid $pid" 
								sudo kill -$1 $pid ;;
        * )                     echo "Not Mapped"
                                exit 1
    esac
    shift
done



