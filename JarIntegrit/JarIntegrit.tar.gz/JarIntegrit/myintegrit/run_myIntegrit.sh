
sudo java -jar -Dlog4j.configuration=file:./src/main/resources/log4j.properties ./target/myintegrit.one-jar.jar