

sudo java -jar -Dlog4j.configuration=file:/home/tlsl/Desktop/JarIntegrit/myintegrit/src/main/resources/log4j.properties /home/tlsl/Desktop/JarIntegrit/myintegrit/target/myintegrit.one-jar.jar &
