
filename="/var/run/myintegrit/myintegrit.pid"




line=$(head -1 $filename)


echo "adsfads - $line"



